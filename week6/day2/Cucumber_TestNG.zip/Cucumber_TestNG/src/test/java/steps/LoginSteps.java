package steps;

import org.openqa.selenium.By;

import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps extends BaseClass {
	
	@Given("Enter the username as {string} and password as {string}")
	public void enterCredentials(String uName,String pWord) {
	   driver.findElement(By.id("username")).sendKeys(uName);
	   driver.findElement(By.id("password")).sendKeys(pWord);
	}

	@When("Click on the Login button")
	public void click_on_the_login_button() {
	   driver.findElement(By.className("decorativeSubmit")).click();
	}
	
	@Then("HomePage should be displayed")
	public void home_page_should_be_displayed() {
		String title = driver.getTitle();
		if (title.contains("Leaftaps")) {
			System.out.println("HomePage is verified");
		}
		else {
			System.out.println("HomePage is not verified");
		}
	}
	
	@But("ErrorMessage should be displayed")
	public void verifyErrorMsg() {
		String text = driver.findElement(By.id("errorDiv")).getText();
		if (text.contains("Errors")) {
			System.out.println("Error message is verified");
		}
		else {
			System.out.println("Error message is not verified");
		}
	}
	
	
}
