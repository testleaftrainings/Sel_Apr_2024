package steps;

import org.openqa.selenium.By;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateLeadSteps extends BaseClass{
	@When("Click on the crmsfa link")
	public void click_on_the_crmsfa_link() {
		System.out.println(driver);
	    driver.findElement(By.partialLinkText("CRM")).click();
	}

	@When("Click on Leads link")
	public void click_on_leads_link() {
	    driver.findElement(By.linkText("Leads")).click();
	}

	@When("Click on CreateLead link")
	public void click_on_create_lead_link() {
	   driver.findElement(By.linkText("Create Lead")).click();
	}

	@When("Enter the companyname as (.*)$")
	public void enter_the_companyname(String cName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
	}

	@When("Enter the firstname as (.*)$")
	public void enter_the_firstname(String fName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
	}

	@When("Enter the lastname as (.*)$")
	public void enter_the_lastname(String lName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
	}

	@When("Click on the Submit button")
	public void click_on_the_submit_button() {
		driver.findElement(By.name("submitButton")).click();
	}

	@Then("ViewLeads page should be displayed as (.*)$")
	public void view_leads_page_should_be_displayed(String cName) {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(cName)) {
			System.out.println("Lead created successfully");
		}
		else {
			System.out.println("Lead is not created");
		}
	}
}
