package runner;

import io.cucumber.testng.CucumberOptions;
import steps.BaseClass;

@CucumberOptions(features={"src/test/java/features"},
                 glue={"steps"},
                 monochrome = true,
                 publish=true,
                // tags="@regression")// to execute only particular category
                // tags="not @regression")// to exclude the particular scenario
                // tags="@regression or @functional")
                 tags="@regression and @smoke")
public class CucumberRunner extends BaseClass{

}
