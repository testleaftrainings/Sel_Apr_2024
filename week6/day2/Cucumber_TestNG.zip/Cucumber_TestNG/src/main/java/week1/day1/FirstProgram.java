package week1.day1;

public class FirstProgram {
	
	// create a main method -> shortcut -> type main -> ctrl+space -> click enter
	
	public static void main(String[] args) {
		
		// print a statement
		// type syso -> ctrl + space -> click enter
		System.out.println("Welcome to TestLeaf");
		
	}
	

}
