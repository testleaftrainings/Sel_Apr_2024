package week1.day1;

public class LearnForLoop {

	public static void main(String[] args) {
		// print even numbers from 1 to 20
		// type for  -> ctrl +space -> click 2nd for loop -> Click enter

		for (int i = 1 ; i <20; i++) { // i=4 ; 4<=20 -> T ; 1++
			if(i%2==0) { // 4%2 == 0 -> t
				System.out.println(i);// 2 4
			}

		}
	}

}
