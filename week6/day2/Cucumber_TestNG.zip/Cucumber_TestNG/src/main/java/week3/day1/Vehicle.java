package week3.day1;

public class Vehicle {
	
	public void applyBrake() {
		System.out.println("Brake applied -> From Vehicle class");
	}
	public void applySoundHorn() {
		System.out.println("Hey Please move -> From Vehicle class");
	}
}
