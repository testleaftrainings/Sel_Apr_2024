package week7.day1;

public class EmployeeInfo {
	/**
	 * Constructor:
	 *    It is used to initialize the state of an object
	 *    The constructor and method will look like same
	 *    but the differences are
	 *      Constructor should be created with the classname  
	 *      Will not have any return statements(either void/primitive/non primitive datatypes)
	 *  Types:
	 *     Default Constructor
	 *     Parameterized Constructor   
	 *       Constructor Overloading 
	 *   this keyword:
	 *       It is used to differentiate the global variable and the local variable if its has the same name within a class
	 *       Can you call one Constructor from another Constructor?
	 *        Yes, Which is called as Constructor chaining which can be achieved using this keyword 
	 *        Constructor call must be the first statement in a constructor
	 */

	int empId;
	String empName;
	boolean empStatus;

	public EmployeeInfo() {
		this(300, "Subi", true);
		System.out.println("Default Constructor");

	}
	
	public EmployeeInfo(int empId, String empName, boolean empStatus){
//		this();
		System.out.println("Paramterized Constructor");
		this.empId=empId;
		this.empName=empName;
		this.empStatus=empStatus;
	}
	


	public static void main(String[] args) {
		EmployeeInfo ei = new EmployeeInfo();
		System.out.println(ei.empId+" "+ei.empName+" "+ei.empStatus);
		
//		EmployeeInfo ei = new EmployeeInfo(200, "Vidhya", true);
//		System.out.println(ei.empId+" "+ei.empName+" "+ei.empStatus);
		
	}

}
