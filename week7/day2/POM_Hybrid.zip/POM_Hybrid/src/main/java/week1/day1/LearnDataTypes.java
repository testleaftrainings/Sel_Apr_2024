package week1.day1;

import week1.day2.LearnObjects;

public class LearnDataTypes {
	
	public static void main(String[] args) {
		
// datatype variablename = value;		
	 int	age = 30;  // default value = 0
     long phoneNumber = 9876543210L;	// default value = 0L
     float height = 5.2f; // default value = 0.0f
     double bankBalance = 10007.8988; // default value = 0.0d
     char logo = 'H'; // default value = '\u0000'
     String registrationNumber = "TN000078";   // default value = null
     boolean isMarried = true; // default value = false
     
     System.out.println("The age is : "  +age);
     System.out.println(phoneNumber + "\n" +height + "\n" +bankBalance) ;
     System.out.println(phoneNumber);
     System.out.println(height);
     System.out.println(bankBalance);
     System.out.println(logo);
     System.out.println(registrationNumber);
     System.out.println(isMarried);
	
     
	}

}
