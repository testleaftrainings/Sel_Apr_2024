package week5.day1.testcase;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Amazon {

	public static void main(String[] args) throws InterruptedException {
ChromeDriver driver = new ChromeDriver();
        
        // Launch Amazon site
        driver.get("https://www.amazon.in/");
        
        // Maximize the window
        driver.manage().window().maximize();
        
        // Add implicit wait
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        
        // Type text in input for Bags for b
        driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Bags for b");
        Thread.sleep(2000);
        
        // Find and select Bags for boys from suggested option list
        List<WebElement> suggestedOptions = driver.findElements(By.xpath("//div[@class='left-pane-results-container']//div[@class='s-suggestion-container']"));
        for (WebElement suggestedOption : suggestedOptions) {
            if (suggestedOption.findElement(By.tagName("div")).getText().contains("bags for boys")) {
                suggestedOption.click();
                break;
            }
        }
        Thread.sleep(2000);
        
        // Get the search results
        System.out.println("Search Results: " + driver.findElement(By.xpath("//span[@data-component-type='s-result-info-bar']//h1[contains(@class,'s-desktop-toolbar')]//div[contains(@class,'s-breadcrumb')]//div[contains(@class,'a-section')]")).getText());
        
        // Select the brand "Skybags"
        driver.findElement(By.xpath("//div[@id='brandsRefinements']//li//span[text()='Skybags']")).click();
        Thread.sleep(3000);
        
        // Select the brand "Gear"
        driver.findElement(By.xpath("//div[@id='brandsRefinements']//li//span[text()='Gear']")).click();
        Thread.sleep(3000);
        
        // Sort from the feature dropdown
        WebElement sort = driver.findElement(By.id("s-result-sort-select"));
        Select sortOption = new Select(sort);
        sortOption.selectByVisibleText("Newest Arrivals");
        Thread.sleep(2000);
        
        // Scroll to the bottom
        driver.executeScript("window.scrollTo(0, document.body.scrollHeight)");
        
        // Get first displayed bag details with staleness handling
        List<WebElement> bagsList = fetchElementsWithRetry(driver, By.xpath("//div[@data-component-type='s-search-result']"));
        
        if (bagsList != null && !bagsList.isEmpty()) {
            WebElement firstBag = bagsList.get(0);
            String bagTitle = firstBag.findElement(By.cssSelector("h2 a span")).getText();
            String bagPrice = firstBag.findElement(By.cssSelector("span.a-price-whole")).getText();
            String symbol = firstBag.findElement(By.cssSelector("span.a-price-symbol")).getText();
            System.out.println("Bag Title: " + bagTitle + '\n' + "Bag Price: " + symbol + bagPrice);
        } else {
            System.out.println("No bags found.");
        }
        
        // Close the driver
        //driver.close();
    }
    
    // Helper method to fetch elements with retry on staleness
    private static List<WebElement> fetchElementsWithRetry(ChromeDriver driver, By locator) {
        List<WebElement> elements = null;
        int attempts = 0;
        
        while (attempts < 3) {
            try {
                elements = driver.findElements(locator);
                // Check if the first element is stale
                if (elements != null && !elements.isEmpty()) {
                    new WebDriverWait(driver, Duration.ofSeconds(5)).until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
                }
                break;
            } catch (StaleElementReferenceException e) {
                attempts++;
                // Re-fetch elements
                elements = driver.findElements(locator);
            }
        }
        
        return elements;
	}
}
