package week3.day2;

public interface Payments {
	
	public void upiPayment();
	

}
