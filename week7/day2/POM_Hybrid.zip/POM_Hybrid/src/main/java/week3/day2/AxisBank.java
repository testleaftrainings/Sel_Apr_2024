package week3.day2;

public class AxisBank implements RBI{

	public void knowYourCustomer() {
		System.out.println("PAN Card");
		
	}

	public int withDrawalLimit() {
		
		return 50000;
	}
	
	public void goldLoan() {
		System.out.println("7% interest rate");

	}

	public void repoRate() {
		System.out.println("8%");
		
	}

	@Override
	public void upiPayment() {
		// TODO Auto-generated method stub
		
	}

}
