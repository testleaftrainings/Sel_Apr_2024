package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.When;

public class MyLeadsPage extends BaseClass{
	@When("Click on CreateLead link")
	public CreateLeadPage click_on_create_lead_link() {
		getDriver().findElement(By.linkText("Create Lead")).click();
		return new CreateLeadPage();
	}
}
