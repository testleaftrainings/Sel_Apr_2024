package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {
	
	@Given("Enter the username as {string} and password as {string}")
	public LoginPage enterCredentials(String uName,String pWord) {
	   getDriver().findElement(By.id("username")).sendKeys(uName);
	   getDriver().findElement(By.id("password")).sendKeys(pWord);
	   return this;
	}

	@When("Click on the Login button")
	public WelcomePage click_on_the_login_button() {
	   getDriver().findElement(By.className("decorativeSubmit")).click();
	   return new WelcomePage();
	}
	
	
}
