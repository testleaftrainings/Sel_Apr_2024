package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests{
	
	public String fileName;
	private static final ThreadLocal<ChromeDriver> cdDriver = new ThreadLocal<>();
	
	//Sets the current thread's copy of this thread-local variable
	public void setDriver() {
		cdDriver.set(new ChromeDriver());
	}
	
	//Returns the value in the current thread's copy of this variable
	public ChromeDriver getDriver() {
		return cdDriver.get();

	}
	
	@BeforeMethod
	public void preCondition() {
		  setDriver();
		  getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		  getDriver().manage().window().maximize();
		  getDriver().get("http://leaftaps.com/opentaps/control/main");
	}
	
	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}
	
	@DataProvider(name="fetchData",parallel=true)
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(fileName);
	}

}
