package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {
	
	@Given("Enter the username as {string} and password as {string}")
	public void enterCredentials(String uName,String pWord) {
	   driver.findElement(By.id("username")).sendKeys(uName);
	   driver.findElement(By.id("password")).sendKeys(pWord);
	}

	@When("Click on the Login button")
	public void click_on_the_login_button() {
	   driver.findElement(By.className("decorativeSubmit")).click();
	}
	
	
}
