package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.When;

public class MyLeadsPage extends BaseClass{
	@When("Click on CreateLead link")
	public void click_on_create_lead_link() {
	   driver.findElement(By.linkText("Create Lead")).click();
	}
}
