package week3.day2;

public class Bank extends SBIBankMoutRoad{
	
	public static void main(String[] args) {
		Bank bi = new Bank();
		bi.cibilScore();
		bi.withDrawalLimit();
		bi.homeLoan();
	}
	
	

	public int withDrawalLimit() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void repoRate() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cibilScore() {
		// TODO Auto-generated method stub
		
	}

}
