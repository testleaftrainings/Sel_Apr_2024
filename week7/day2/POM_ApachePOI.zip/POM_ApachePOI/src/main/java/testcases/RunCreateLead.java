package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunCreateLead extends BaseClass{
	
	@BeforeTest
	public void setValues() {
		fileName="CreateLead";
	}
	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String uName,String pWord,String cName,String fName,String lName) {
		new LoginPage(driver)
		.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.verifyHomePage()
		.clickCRMSFALink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyname(cName)
		.enterFirstname(fName)
		.enterLastname(lName)
		.clickSubmitButton()
		.verifyLeads(cName);
	}

}
