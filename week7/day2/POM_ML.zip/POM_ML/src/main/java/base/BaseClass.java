package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

public class BaseClass {
	public ChromeDriver driver;
	public static Properties prop;
	
	@Parameters("language")
	@BeforeMethod
	public void preCondition(String lang) throws IOException {
		if (lang.equalsIgnoreCase("en")) {
			FileInputStream fis = new FileInputStream("src/main/resources/config.en.properties");
			prop = new Properties();
			prop.load(fis);
		}
		else if(lang.equalsIgnoreCase("fr")) {
			FileInputStream fis1 = new FileInputStream("src/main/resources/config.fr.properties");
			prop = new Properties();
			prop.load(fis1);
		}


		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("http://leaftaps.com/opentaps/control/main");
	}

	@AfterMethod
	public void postCondition() {
		driver.close();
	}



}
