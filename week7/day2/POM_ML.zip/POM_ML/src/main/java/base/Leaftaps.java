package base;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Leaftaps {
	
	public static void main(String[] args) throws IOException {
		
		FileInputStream fis = new FileInputStream("src/main/resources/config.fr.properties");
		Properties prop = new Properties();
		prop.load(fis);
		
		// read the value from the property file
		String userVal = prop.getProperty("username");
		System.out.println(userVal);
		
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.findElement(By.id("username")).sendKeys(userVal);
		driver.findElement(By.id("password")).sendKeys(prop.getProperty("password"));
		
	}

}
