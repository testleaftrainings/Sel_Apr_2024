package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.When;

public class MyHomePage extends BaseClass{
	@When("Click on Leads link")
	public MyLeadsPage click_on_leads_link() {
	    getDriver().findElement(By.linkText("Leads")).click();
	    return new MyLeadsPage();
	}
}
