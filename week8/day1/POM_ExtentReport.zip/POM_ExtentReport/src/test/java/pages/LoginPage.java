package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass {

	@Given("Enter the username as {string} and password as {string}")
	public LoginPage enterCredentials(String uName,String pWord) throws IOException {
		try {
			getDriver().findElement(By.id("username")).sendKeys(uName);
			reportStep(uName +  " is entered successfully", "pass");
		} catch (Exception e) {
			reportStep(uName + " is not entered successfully" +e, "fail");
		}
		try {
			getDriver().findElement(By.id("password")).sendKeys(pWord);
			reportStep(pWord+ " is entered successfully", "pass");
		} catch (Exception e) {
			reportStep(pWord + " is not entered successfully "+e, "fail");
		}
		return this;
	}

	@When("Click on the Login button")
	public WelcomePage click_on_the_login_button() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Login button is clicked successfully", "pass");
		} catch (Exception e) {
			reportStep("Login button is not clicked successfully" +e, "fail");
		}
		return new WelcomePage();
	}


}
