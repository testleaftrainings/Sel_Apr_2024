package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class ViewLeadsPage extends BaseClass{
	@Then("ViewLeads page should be displayed as (.*)$")
	public void view_leads_page_should_be_displayed(String cName) {
		String text = getDriver().findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(cName)) {
			System.out.println("Lead created successfully");
		}
		else {
			System.out.println("Lead is not created");
		}
	}
}
