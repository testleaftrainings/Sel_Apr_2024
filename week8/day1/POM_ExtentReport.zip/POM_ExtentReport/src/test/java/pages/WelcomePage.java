package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class WelcomePage extends BaseClass {
	
	@Then("HomePage should be displayed")
	public WelcomePage home_page_should_be_displayed() {
		String title = getDriver().getTitle();
		if (title.contains("Leaftaps")) {
			System.out.println("HomePage is verified");
		}
		else {
			System.out.println("HomePage is not verified");
		}
		return this;
	}
	
	@But("ErrorMessage should be displayed")
	public WelcomePage verifyErrorMsg() {
		String text = getDriver().findElement(By.id("errorDiv")).getText();
		if (text.contains("Errors")) {
			System.out.println("Error message is verified");
		}
		else {
			System.out.println("Error message is not verified");
		}
		return this;
	}
	
	@When("Click on the crmsfa link")
	public MyHomePage click_on_the_crmsfa_link() {
	    getDriver().findElement(By.partialLinkText("CRM")).click();
	    return new MyHomePage();
	}
	
}
