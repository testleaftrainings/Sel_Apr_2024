package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunLogin extends BaseClass{
	
	@BeforeTest
	public void setValues() {
		fileName="Login";
		testName="Login";
		testDescription="Login with valid data";
		testAuthor="Subraja";
		testCategory="smoke";
	}
	
	@Test(dataProvider = "fetchData")
	public void runLogin(String uName,String pWord) throws IOException {
		new LoginPage()
		.enterCredentials(uName, pWord)
		.click_on_the_login_button()
		.home_page_should_be_displayed();
	}

}
