package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunCreateLead extends BaseClass{

	@BeforeTest
	public void setValues() {
		fileName="CreateLead";
		testName="Create Lead";
		testDescription="CreateLead with multiple data";
		testAuthor="Subraja";
		testCategory="regression";

	}

	@Test(dataProvider = "fetchData")
	public void verifyCreateLead(String uName,String pWord,String cName,String fName,String lName) throws IOException {
		new LoginPage()
		.enterCredentials(uName, pWord)
		.click_on_the_login_button()
		.home_page_should_be_displayed()
		.click_on_the_crmsfa_link()
		.click_on_leads_link()
		.click_on_create_lead_link()
		.enter_the_companyname(cName)
		.enter_the_firstname(fName)
		.enter_the_lastname(lName)
		.click_on_the_submit_button()
		.view_leads_page_should_be_displayed(cName);

	}

}
