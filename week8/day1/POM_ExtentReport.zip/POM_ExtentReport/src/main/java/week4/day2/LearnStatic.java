package week4.day2;

public class LearnStatic {
	public static void main(String[] args) {
		//classname.staticmethod()
		EmployeeDetails.add(34, 90);
	}

}
